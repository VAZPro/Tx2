let cuoc = [];

module.exports  = cuoc;