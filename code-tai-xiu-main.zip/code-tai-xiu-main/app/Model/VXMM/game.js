let vongquay = {
    id : -1,
    xu : 0,
    win : 0,
    a : 0,
    b : 0,
    trangthai : ''
};

module.exports = vongquay;