# NroServer

Như đã nói, code là hàng học tập, đừng bro nào vui tính mà đem bán hay mở kinh doanh, nghe nó hãm vcl.
Code là hàng h tập, vì thế, các b hãy sử dung đúng m đích để h tập.

# Cài Đặt

1. Cài Nodejs
2. Update file **Nro.sql** lên sql của bạn.
3. vào **app/model/mysql.js** edit config sql.
4. **cd** tới thư mục chứa server
5. gõ lệnh **node install**
6. gox lệnh **node server** hoặc **node app** hoặc **node server.js** để chạy 


# cài đặt client

1. donwload client về.
2. Mở file **Models/main.js** dòng 10 edit IP từ **192.168.1.5** thành **127.0.0.1**
3. thư muc admin là **/ditmeducnghia**, edit caasu hình ip tng tự như trên. 
